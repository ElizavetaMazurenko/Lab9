module ImplicitHelper
end
